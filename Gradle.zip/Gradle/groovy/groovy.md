# Groovy简介

* Groovy是一种领域特定语言(Domain Specific Language) 简称 DSL  (DSL不像其他语言具有通用性 而是专注于某个特定领域 用于解决特定的问题)
* Groovy是基于JVM的敏捷开发语言 因此经过前端编译也会产生 .class文件  除此之外 Groovy结合Python、Ruby等强大特性 对Java进行了扩展 
* Groovy可以使用Java的核心内库 且 语法上支持动态类型 闭包等语言特性
* Groovy支持面向队形编程 也支持面向过程编程

# 环境搭建



# Groovy语法

## Groovy基础语法

### 变量

#### 变量类型

* Groovy中的变量类型与Java一致 分为 基本类型和引用类型 但是Groovy中的基本类型最终都会被包装为包装类 因此在Groovy中 变量的类型只有一种 即 引用类型

```groovy
package basic

int x = 1
println x.class // class java.lang.Integer

double y = 1.0
println y.class // class java.lang.Double
```



#### 变量的定义

* 在Groovy中变量的定义方式有两种 一种为 强类型定义 一种为弱类型定义 其中强类型定义就是在变量定义时 明确指定出变量的类型 而弱类型的定义则是 使用 def 关键字来定义变量 变量的具体类型有编译器来自动适配

```groovy
package basic

def x = 1
println x.class // class java.lang.Integer
// def关键字可以省略
y = 1.0
println y.class // class java.lang.Double

z = "string"
println z.class // class java.lang.String
```

* 除此之外 通过def定义的变量 可以分别赋予不同类型的值 因为具体的类型会在编译时进行确定

```java
package basic

def x = 1
println x.class // class java.lang.Integer

x = "string"
println x.class // class java.lang.String

```

编译称为.class文件后 如下

```java
package basic;

import groovy.lang.Binding;
import groovy.lang.Script;
import org.codehaus.groovy.runtime.InvokerHelper;
import org.codehaus.groovy.runtime.callsite.CallSite;

public class GroovyVariable extends Script {
    public GroovyVariable() {
        CallSite[] var1 = $getCallSiteArray();
        super();
    }

    public GroovyVariable(Binding context) {
        CallSite[] var2 = $getCallSiteArray();
        super(context);
    }

    public static void main(String... args) {
        CallSite[] var1 = $getCallSiteArray();
        var1[0].callStatic(InvokerHelper.class, GroovyVariable.class, args);
    }

    public Object run() {
        CallSite[] var1 = $getCallSiteArray();
        // def x = 1
        Object x = 1;
        var1[1].callCurrent(this, var1[2].callGetProperty(x));
        // x = "string"
        String var3 = "string";
        return var1[3].callCurrent(this, var1[4].callGetProperty(var3));
    }
}

```

* 观察 run方法 内部的内容 可以知道 变量的类型会在编译期间确定



当变量只在 本类中进行使用 可以使用def进行定义 而一旦需要被外部使用 则需要使用强类型定义 以确保参数类型的准确



### 字符串

* 在Groovy中提供了两种字符串 一种为String 与Java中的用法一致 另一种为GString 对String做了一些拓展

#### GString的常见定义方式

* 在Groovy 中定义字符串的方式有 三种  如下:

##### '' 定义字符串

* 使用''定义的字符串 满足所见即所得的特点 也就是说 '' 内部的字符都会被定义为字符串

```groovy
package basic.variable.string

abc = 'string'
str = 'abc + ${abc} + d '
println str // abc + ${abc} + d 
println str.class // class java.lang.String
```



##### ""定义字符串

* 使用 "" 定义的字符串 允许使用 拓展表达式 ${表达式}   拓展表达式内的值 根据表达式的定义动态加载
* 当在""定义的字符串内使用了 拓展表达式 那么该字符串会转换为 GString 而 不再是 String

```groovy
package basic.variable.string

abc = 'string'
str = "abc + ${abc} + d "
println str // abc + string + d 
println str.class // class org.codehaus.groovy.runtime.GStringImpl
```

* 在Groovy中 GString和String是可以想换转换的 且这个过程会由编译器自动进行

```groovy
// 定义方法 
String gString2String(String str) {
    return str;
}

println gString2String("${2 + 3}") // 5
println gString2String("${2 + 3}").class // class java.lang.String
```



##### '''''' 定义字符串

* 使用''''''定义的字符串与''定义的一致也满足所见即所得的特点 但是允许换行且不用显示的添加换行符

```groovy
package basic.variable.string

abc = 'string'
str = '''
abc 
+ ${abc} 
+ d '''
println str // abc 
			// + ${abc} 
			// + d 
println str.class // class java.lang.String
```



#### GString常用API

* 在Groovy中 字符串类型变量处理可以使用 java.lang.String中的方法外 Groovy还额外提供了 StringGroovyMethods类  这个类对字符串的使用做了拓展  简单的介绍几种方法 

##### 字符串填充

######center()方法 

* 以当前字符串为中心 填充指定字符将当前字符串填充到指定长度 若指定的长度 <= 当前字符串 则不作任何操作

```groovy
package basic.string

str = "hello Groovy"
str = str.center(16,"0")
println str // 00hello Groovy00
```

###### padLeft()

* 在当前字符串的左侧填充指定字符 将当前字符串填充到指定长度 若指定的长度 <= 当前字符串 则不作任何操作

```groovy
package basic.string

str2 = "hello Groovy"
str2 = str2.padLeft(16, "0")
println str2 // 0000hello Groovy
```

###### padRight

* 在当前字符串的右侧填充指定字符 将当前字符串填充到指定长度 若指定的长度 <= 当前字符串 则不作任何操作

```java
package basic.string

str3 = "hello Groovy"
str3 = str3.padRight(16, "0")
println str3 // hello Groovy0000
```



##### 字符串的比较

* Groovy中的字符串与Java中的一样 是可以进行大小比较的 默认情况下 使用字典序

```groovy
package basic.string

str1 = "abc"
str2 = "bcd"
result = str1.compareTo(str2)
println result // -1 
```

* 上述的写法 调用的 java.lang.String中的compareTo 方法  而在Groovy中对该方法进行了简化 如下所示

  <=> 操作符 等价于 调用 compareTo ()方法

```groovy
package basic.string

str1 = "abc"
str2 = "bcd"
result = str1 <=> str2
println result // -1
```

* 也就是说 字符串在比较时可以使用操作符直接进行比较 (本质上依旧是方法的调用) 从而简化代码

```groovy
package basic.string

str1 = "abc"
str2 = "bcd"
println str1 > str2 // false
println str1 < str2 // true
```



##### 字符串的截取

* 在Groovy中 可以直接使用 "-" 来对字符串进行截取 如 a - b 

  当 b是a的子串时 a - b 的到的结果 就是 字符串a 去除 b 后剩余的部分 (只会截取 a 中从左往右第一个子串)

  若a中不包含b 则不作任何操作

```groovy
package basic.string;

str1 = 'abcdef'
str2 = "def"
println str1 - str2; // abc
```



##### 字符串中元素的获取

* 在Groovy中 字符串中元素的获取除了 可以调用 getAt()方法之外 还提供了其他的操作方式

```groovy
package basic.string

str = "hello groovy"

// 1.使用 getAt() 获取元素
println str.getAt(0) // h

// 2. 直接使用索引的方式获取元素(本质上还是调用 getAt()方法)
println str[0] // h
println str[-1] // y  使用 -1 则获取最右边的第一个元素

// 3. 获取指定范围内的元素 从右往左获取条件范围内的元素
println str[-5..0] // rg olleh  
```

* 尽管字符串的获取形式 作出了简化 但底层依旧是一致的 因此元素的获取依旧需要注意索引越界的情况 避免出现索引越界的异常



### 逻辑控制

* 逻辑控制分为以下几种
  * 顺序逻辑 : 单步依次执行
  * 条件逻辑:
    * if/else
    * switch/case
  * 循环逻辑
    * while循环
    * for循环

在Groovy中 对条件逻辑中的 switch/case 和 循环逻辑中 for循环进行了扩展 其他的与Java语法一致 因此需要主要研究的就是 switch/case 与 for循环的拓展

#### switch/case

* 在Groovy中 switch/case支持所有类型变量 (Java中只支持 整型 字符型 String 以及 枚举类型) 并且 使用更加的灵活

```groovy
package basic.logicControl;
// switch/case的使用
void method(x) {
    def result;
    switch (x) {
        // x==12
        case 12:
            result = 'x is 12'
            break
        // x == "12"
        case "12":
            result = 'x is String'
            break
        // x在 1 - 15 范围内
        case 1..15:
            result = 'x is number and in range 1 to 15'
            break
        // x 在列表内
        case [1,12,15,"22"]:
            result = 'x in list'
            break
        // x 属于 Integer类型
        case Integer:
            result = 'the type of x is Integer'
            break
        // x 属于 String类型
        case String:
            result = 'the type of x is String '
            break
        // 以上条件都不满足
        default:
            result = 'default'
    }
    println result
}

method(12)      // x is 12
method("12")    // x is String
method("22")    // x in list
method(100)     // the type of x is Integer
```



#### for循环

* Groovy中特有的for循环如下

```groovy
package basic.logicControl

// 1. 对范围 for循环 [1,10] 遍历
for (i in 1..10) {
    print(i + " ") // 
}

// 2. 对list 循环
for (num in [1, 2, 3, 4, 5, 6]) {
    print(num + " ") // 1, 2, 3, 4, 5, 6
}

// 3. 对map循环
for (map in ['key1': 1, 'key2': 2]) {
    print map.key + ' = ' + map.value +"  " //  key1 = 1  key2 = 2
}

```



## Groovy闭包

### 闭包的定义&调用

* 闭包的本质是一段代码块 与方法类似 但又不是方法 在Groovy中 闭包属于 Closure的具体实例
* 闭包的定义与弱类型变量定义一致 同样使用 def关键字进行定义 在{}的内部可以定义参数和接收参数 以及 书写代码逻辑

#### 闭包的基本定义与调用

* 闭包的定义和调用如下

```groovy
// 闭包的定义
def closure = {
    int result = 10
    println result;

}
// 闭包的调用
// 1. 通过闭包名.call()调用
closure.call() // 10
// 2. 直接使用闭包名()调用
closure() // 10
```



#### 闭包的参数接收

##### 普通参数

*  在闭包中除了可以定义变量外 还可以接收参数  使用 " $->$" 标识 具体如下

```groovy
package basic.closure

def parameter1 = {
     name, int age ->
        println "name = ${name} age = ${age}"

}
parameter1("陈平安",18) // name = 陈平安 age = 18
```

闭包中的参数 可以指定类型 也可以不指定 甚至可以部分指定  在部分指定的情况下 参数默认为 Object类型的可变参数 但是运用时 建议指定参数类型 防止出现类型转换或者方法调用上的错误

* $->$ 只能不书写其他内容 或只定义要接收的参数 否则会报错 若需要使用 参数 必须在 $->$ 后定义

```groovy
package basic.closure

def parameter2 = {
    String name, String gender ->
        int age = 18
        println "name = ${name} gender = ${gender} age = ${age}"
}
parameter2("陈平安", "男")
```

* 当闭包接收的参数放在" ()" 则需要传递一个列表作为参数 若在 $->$ 后定义变量 需要添加 { } 且只能定义弱类型变量

```groovy
package basic.closure

def parameter3 = {
    (String name, String gender) ->
        def age = 18
        println "name = ${name} gender = ${gender} age = ${age}"
}
// parameter3("陈平安", "男") // 报错 basic.closure.ClousureGroocy$_run_closure4.call() is applicable for argument types: (String, String) values: [陈平安, nan]

parameter3(["陈平安", "nan"]) // name = 陈平安 gender = 男 age = 18
```

##### 隐藏参数

 闭包提供了一个隐藏参数 参数名为 it 在不使用" $->$ " 的情况下 可以直接进行使用

```groovy

def hideParameter = {
    println "${it}" // 陈平安
}

hideParameter("陈平安")
```



#### 闭包的返回值

* 闭包中默认带有返回值 在不显示的 使用 return 关键字的情况下 默认返回 null

```groovy
package basic.closure

def result = {

}
println result() // null

result ={
    return "result"
}
println result() // result
```



### 闭包的使用

* 闭包的使用 较为灵活 主要有4个部分的使用 与基本类型的结合使用 与String的结合使用 与数据结构结合使用 以及与文件结合使用

  在这一小节中 只涉及 与基本类型的结合使用 以及与String类型的结合使用  

#### 闭包与基本类型的结合使用

* 闭包与基本类型的结合使用(严格意义上来讲是与基本类型的包装类结合使用) 是将闭包作为方法调用的参数来使用的 因为闭包的本质就是一个 Closure实例

##### 闭包与Integer的upto()方法的结合

* upto方法需要两个参数 一个为Number类型一个为 Closure类型 它的作用是 将一个值 递增到指定结果 每次递增1 并且在递增过程中每一次的递增都会执行闭包中的内容体

```groovy
package basic.use4closure

// 定义方法 求 1到 num 的阶乘
int multi(int num) {
    int result = 1
    1.upto(num,{
        // number为 1每次累加的值
        number->
            result *= number
    })
    return result
}
println multi(5) // 120
```

* 观察上述代码  在闭包中定义了参数 而且只定义了1个参数 参数的确定需要观察 upto()方法的具体实现来确定

  upto()的方法定义如下

```java
    public static void upto(Number self, Number to, @ClosureParams(FirstParam.class) Closure closure) {
        int self1 = self.intValue();
        int to1 = to.intValue();
        if (self1 > to1) {
            throw new GroovyRuntimeException("The argument (" + to + ") to upto() cannot be less than the value (" + self + ") it's called on.");
        } else {
            for(int i = self1; i <= to1; ++i) {
                closure.call(i);
            }

        }
    }
```

观察方法的实现 可以知道 闭包中只需要一个参数 根据 call()方法内部的参数传递而确定



##### 闭包与Integer的downto()方法的结合

* downto方法需要两个参数 一个为Number类型一个为 Closure类型 它的作用是 将一个值递减到指定结果 每次累递减 1 并且在递减过程中每一次的递减都会执行闭包中的内容体

* 当闭包时方法最右测的参数时 闭包可以写在()之外

```groovy
package basic.use4closure

int multi2(int num) {
    int result = 1
    num.downto(1) {
            // number为 1每次累加的值
        number ->
            result *= number
    }
    return result
}

println multi2(5) // 120
```



##### 闭包与Integer的downto()方法的结合

* times()方法需要传递一个Closure类型的参数 它的作用是 从 0 开始 进行递增 每次递增1 直到递增到指定结果 -1的值  并且在递增过程中每一次的递增都会执行闭包中的内容体
* 当方法中传递的参数仅有一个闭包参数时 可以省略()

```groovy
package basic.use4closure

int times(int num) {
    int result = 0
    num.times {
        // 使用隐藏参数
        result += it
    }
    return result

}

println times(11) // 55
```



#### 闭包与String的结合使用

* 闭包与String的结合与基本类型一致 也只作为方法参数来使用的 满足与基本类型结合的特点

##### 闭包与each()方法的结合使用

* each()方法 需要接受两个参数 一个是对象本身 (这个参数不需要处理 编译器会自行传递) 另一个则是闭包参数 each()方法会对字符串中的元素进行迭代遍历 并按照 闭包体中定义的操作方式进行操作

```groovy
str = "hello groovy"
str.each {
    // 将每个元素复制两个
    print it * 2 + " " // hh ee ll ll oo    gg rr oo oo vv yy 
}
```



##### 闭包与find()方法的结合使用

* find()方法 同样需要接受两个参数 一个是对象本身 另一个则是闭包参数  find()方法会依次遍历字符串中的元素 当有元素满足闭包体内定义的条件时 则停止 并返回第一个满足条件的元素

```groovy
package basic.use4closure

str = "hello groovy"
println str.find {
    // 查找 等于"o"的元素
   it == "o" // 等效于 it.equals("o")
} // o
```



##### 闭包与findAll()方法的结合使用

* findAll()方法需要接受两个参数 一个是对象本身 另一个则是闭包参数  findAll()会依次遍历字符串中的所有元素 并将符合闭包体内定义的条件的元素按封装在一个Collection中返回

```groovy
package basic.use4closure

str = "hello groovy"
println str.findAll {
     // 筛选 字符串内是否由任意大于 "h"的元素
    it > "h"
} // [l, l, o, r, o, o, v, y]
```



##### 闭包与any()方法的结合使用

* any()方法需要接受两个参数 一个是对象本身 另一个则是闭包参数  any()方法会依次遍历字符串中的元素 当有元素满足闭包体内定义的条件时 则停止 并返回一个布尔值 

```groovy
package basic.use4closure

str = "hello groovy"
println str.any {
    // 判断字符串内是否由任意大于等于 "o"的元素
    it >= "o"
}

```



##### 闭包与every()方法的结合使用

* every()方法需要接受两个参数 一个是对象本身 另一个则是闭包参数  与any()方法不同 every()方法会遍历字符串中所有的元素 任意元素不满足 闭包体中定义的条件时 则停止 并返回 false

```groovy
package basic.use4closure

str = "hello groovy"
println str.every {
    it > "o"
} // false

```



##### 闭包与collect()方法的结合使用

* collect()方法需要接受两个参数 一个是对象本身 另一个则是闭包参数 collect()方法会遍历字符串中的所有元素 并 闭包体对元素进行操作之后的结果 封装在Collection内返回

```groovy
package basic.use4closure

str = "hello groovy"

println str.collect {
    // 将元素大写
    it.capitalize() // [H, E, L, L, O,  , G, R, O, O, V, Y]
}
```



### 闭包的关键变量

* 在闭包中 内置三个变量 this owner delegate
  * this 代表的是当前类(闭包直属的类)的实例对象 若闭包是 static 修饰的 this 代表的是当前类(闭包直属的类)的字节码对象 闭包一旦定义 this 就是确定的
  * owner 代表闭所在的类的对象或者闭包对象 (因为闭包可以嵌套定义)  闭包一旦定义 owner就是确定的
  *  delegate 代表任意对象 默认与 owner所代表的的对象 一致

#### 脚本中直接定义闭包

* 脚本文件名为 KeyVariableGroovy

```groovy
package basic.use4closure

def scriptClosure = {
    // this代表当前脚本对象
    println "scriptClosure this :" + this 
    // scriptClosure this :basic.use4closure.KeyVariableGroovy@67d18ed7
    
    // 不存在闭包的嵌套 因此 owner代表的也是 当前脚本对象
    println "scriptClosure owner :" + owner 
    // scriptClosure owner :basic.use4closure.KeyVariableGroovy@67d18ed7
    
    // 默认情况下 delegate与owner一致
    println "scriptClosure delegate :" + delegate
    // scriptClosure delegate :basic.use4closure.KeyVariableGroovy@67d18ed7

}

scriptClosure.call()

```



#### 脚本的内部类中定义闭包

* 脚本文件名为 KeyVariableGroovy

##### 定义静态闭包 与 静态方法

```groovy
// 定义内部类
class Person {
    def static personClosure = {
        // 当前闭包属于静态闭包且处于Person类中 因此 this代表的是 当前类的字节码对象
        println "classClosure this :" + this 
        // classClosure this :class basic.use4closure.Person
        
        // 当前闭包属于静态闭包且不存在闭包嵌套 因此 owner代表的也是当前类的字节码对象
        println "classClosure owner :" + owner 
        // classClosure owner :class basic.use4closure.Person
        
        // 未对delegate 进行修改 因此 delegate 代表的对象 与 owner 一致
        println "classClosure delegate :" + delegate 
        // classClosure delegate :class basic.use4closure.Person

    }

    def static say() {
        def methodClosure = {
            println "methodClosure this :" + this 
            // methodClosure this :class basic.use4closure.Person
            
            
            println "methodClosure owner :" + owner 
            //  methodClosure owner :class basic.use4closure.Person
            
            
            println "methodClosure delegate :" + delegate 
            // methodClosure delegate :class basic.use4closure.Person
        }
        methodClosure.call()
    }

}

Person.personClosure.call()
Person.say()
```



##### 定义非静态闭包 与 非静态方法

```groovy
class Man {
    def manClosure = {
        // 当前闭包为实例闭包 因此 this 代表当前闭包直属的类的实例对象
        println "classClosure this :" + this 
        // classClosure this :basic.use4closure.Man@66ac5762
        
        // 当前闭包为实例闭包且不存在闭包的嵌套 因此 owner 代表当前闭包直属的类的实例对象
        println "classClosure owner :" + owner 
        
        // classClosure owner :basic.use4closure.Man@66ac5762
        
        // 未对 delegate 进行修改 因此 delegate 与 owner 一致
        println "classClosure delegate :" + delegate 
        // classClosure delegate :basic.use4closure.Man@66ac5762

    }

    def say() {
        def methodClosure = {
            
     		 // 当前闭包为实例方法中的闭包 因此 this 代表当前闭包直属的类的实例对象
            println "methodClosure this :" + this 
            // methodClosure this :basic.use4closure.Man@66ac5762
            
             // 当前闭包为实例闭方法中的包且不存在闭包的嵌套 因此 owner 代表当前闭包直属的类的
             // 实例对象
            println "methodClosure owner :" + owner 
            // methodClosure owner :basic.use4closure.Man@66ac5762
            
             // 未对 delegate 进行修改 因此 delegate 与 owner 一致
            println "methodClosure delegate :" + delegate 
            // methodClosure delegate :basic.use4closure.Man@66ac5762
        }
        // 调用闭包
        methodClosure.call()
    }

}

// 创建 Man实例对象
Man man = new Man()
man.manClosure.call()
man.say()
```



#### 脚本中定义嵌套闭包

* 脚本文件名为 KeyVariableGroovy

##### 不修改 delegate

```groovy
// 定义嵌套闭包
def outClosure = {

    def innerClosure = {
        // this代表当前脚本对象
        println "innerClosure this :" + this 
        // innerClosure this :basic.use4closure.KeyVariableGroovy@3568f9d2
        
        // 存在闭包的嵌套 因此 owner代表当前闭包所处闭包的实例对象
        println "innerClosure owner :" + owner 
        // innerClosure owner :basic.use4closure
        // .KeyVariableGroovy$_run_closure2@46944ca9
        
        // 未对 delegate 进行修改 因此 delegate 与 owner 一致 
        println "innerClosure delegate :" + delegate 
        // innerClosure delegate :basic.use4closure
        // .KeyVariableGroovy$_run_closure2@46944ca9
    }
  	// 调用闭包
    innerClosure.call()
}

// 调用闭包
outClosure.call()

```



##### 修改 delegate

```groovy
// 内部类 Man
class Man {
}

// 定义嵌套闭包
def outClosure = {

    def innerClosure = {
        // this代表当前脚本对象
        println "innerClosure this :" + this 
        // innerClosure this :basic.use4closure.KeyVariableGroovy@3568f9d2
        
        // 存在闭包的嵌套 因此 onwr
        println "innerClosure owner :" + owner 
        // innerClosure owner :basic.use4closure
        // .KeyVariableGroovy$_run_closure2@46944ca9
        
        // 修改delegate 为 Man 实例 因此 delegate 代表 Man实例对象
        println "innerClosure delegate :" + delegate 
        // innerClosure delegate :basic.use4closure.Man@66ac5762
       
    }
   
    // Access to it exceed its access rights 
    // owner定义之后就是确定的 无法更改
    innerClosure.owner = man 
    
     // 修改默认的 delegate对象
    innerClosure.delegate = man
    innerClosure.call()
}

// 调用闭包
outClosure.call()

```



### 闭包委托策略

* 在闭包中存在不同的委托策略 这些委托策略决定了 在闭包中所获取的对象的属性 以及调用实例对象的方法 的对象来源的选择方式
  *  Closure.OWNER_FIRST ( OWNER_FIRST 为闭包的默认选择策略) 优先从 owner对象中获取 获取不到再从 delegate对象中获取
  *  Closure.OWNER_ONLY 只从owner对象中获取
  *  Closure.DELEGATE_FIRST  优先从 delegate对象中获取 获取不到再从 owner对象中获取
  *  Closure.DELEGATE_ONLY 只从delegate对象中获取

#### Closure.OWNER_FIRST

* owner中有对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

student = new Student(name: "陈平安")
teacher = new Teacher(name: "文圣")

// 应用默认闭包委托策略
// 修改delegate
student.classClosure.delegate = teacher

// owner对象拥有name属性 因此从owner中获取
student.toString() // the student name is 陈平安
```

* owner中无对应属性

```groovy
package basic.use4closure

class Student {
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

// 应用默认闭包委托策略
student = new Student()
teacher = new Teacher(name: "文圣")
// 修改delegate
student.classClosure.delegate = teacher

// owner中没有name属性 从 delegate中获取
student.toString() // the student name is 文圣
```



#### Closure.OWNER_ONLY

* owner中有对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

student = new Student(name: "陈平安")
teacher = new Teacher(name: "文圣")

// 修改闭包委托策略为 OWNER_ONLY
student.classClosure.resolveStrategy = Closure.OWNER_ONLY
// 修改delegate
student.classClosure.delegate = teacher

// 只从owner中获取
student.toString() // the student name is 陈平安


```

* owner中无对应属性

```groovy
package basic.use4closure

class Student {
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

student = new Student()
teacher = new Teacher(name: "文圣")

// 修改闭包委托策略为 OWNER_ONLY
student.classClosure.resolveStrategy = Closure.OWNER_ONLY
// 修改delegate
student.classClosure.delegate = teacher
// 由于当前策略是只从 owner中获取 而 owner中没有 name属性 因此会报错
student.toString() 
// groovy.lang.MissingPropertyException: No such property: name for class: basic.use4closure.Student

```



####Closure.DELEGATE_FIRST

* delegate有对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

student = new Student(name: "陈平安")
//student = new Student()
teacher = new Teacher(name: "文圣")

// 修改闭包委托策略为 DELEGATE_FIRST
student.classClosure.resolveStrategy = Closure.DELEGATE_FIRST
// 修改delegate
student.classClosure.delegate = teacher

// 优先从 delegate对象中获取
student.toString() // the student name is 文圣
```

* delegate无对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {

}

student = new Student(name: "陈平安")
teacher = new Teacher()

// 修改闭包委托策略为 DELEGATE_FIRST
student.classClosure.resolveStrategy = Closure.DELEGATE_FIRST
// 修改delegate
student.classClosure.delegate = teacher

// 优先从 delegate对象中获取而 然后向owner中获取
student.toString() // the student name is 陈平安
```



#### Closure.DELEGATE_ONLY 

* delegate有对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
    String name
}

student = new Student(name: "陈平安")
//student = new Student()
teacher = new Teacher(name: "文圣")
//teacher = new Teacher()

// 应用默认闭包策略
student.classClosure.resolveStrategy = Closure.DELEGATE_ONLY
// 修改delegate
student.classClosure.delegate = teacher

// 从delegate中获取 name
student.toString() // the student name is 文圣

```

* delegate无对应属性

```groovy
package basic.use4closure

class Student {
    String name
    def classClosure = {
        println "the student name is ${name}"
    }
    // 重写 toString 方法
    String toString() {
        classClosure.call()
    }
}

class Teacher {
}

student = new Student(name: "陈平安")
teacher = new Teacher()

// 修改闭包委托策略为 DELEGATE_ONLY
student.classClosure.resolveStrategy = Closure.DELEGATE_ONLY
// 修改delegate
student.classClosure.delegate = teacher
// 报错 因为 delegate对象中没有name属性
student.toString() 
// groovy.lang.MissingPropertyException: No such property: name for class: basic.use4closure.Teacher
```



## Groovy的数据结构

### 列表

#### 列表的定义

* Groovy中 列表(集合)的定义 与Java存在较大的区别 列表在定义时就可以显示赋值

```groovy
package basic.dataStructure.list

// 定义列表
def list = [1,2,3,4,5]
println list.class  // class java.util.ArrayList
println list.size() // 5
```

* 在groovy中也可以定义数组 使用强类型指定即可 或者 将list 转换为数组 前提是 list可以转换为数组 

  另外数组的操作与列表一致

```groovy
// 定义列表
def list = [1, 2, 3, 4, "5"]

// 将list转换为数组
list = list as int[]

println list.class // class [I   groovy中允许 数字字符串直接转换为 数字数组
println list.size() // 5


// 强制指定数组
int[] arr = [1,2,3] 

println arr.class    // class [I
println arr.size()   // 3
```



#### 列表的操作

##### 添加元素

```groovy
package basic.dataStructure.list

def list = [1,2,3,4,5]

// 新增元素

// 1. 末尾追加
list.add(6)
println list // [1, 2, 3, 4, 5, 6]

// 2 . 向左追加 本质上与 add() 方法一致  但可以简写 为 << 要追加的元素
list.leftShift(7) // 追加 7
list << 8  // 追加 8
println list // [1, 2, 3, 4, 5, 6, 7, 8]


// 3. 合并两个列表 并返回新的新的列表
println list + [9,10] // [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
```



##### 删除元素

```groovy
package basic.dataStructure.list

def list = [1, 2, 3, 4, 5, 6, 7, 8]

// 删除元素
// 1.删除索引为1的元素
list.remove(1)
println list // [1, 3, 4, 5, 6, 7, 8]

// 2. 删除指定元素
list.remove((Object)3)
println list // [1, 4, 5, 6, 7, 8]

// 3. 删除指定索引处的元素 
list.removeAt(0) 
println list // [4, 5, 6, 7, 8]

// 4. 删除指定元素
list.removeElement(5)
println list // [4, 6, 7, 8]

// 5. 删除符合条件的元素
list.removeAll {
    // 删除偶数
    it %2 == 0
}
println  list // [ 7]

```



##### 修改元素

```groovy
package basic.dataStructure.list

def list = [1, 2, 3, 4, 5, 6, 7, 8]

// 修改元素
// 1. 使用set()方法 修改指定索引处的元素
list.set(0,0)
println list // [0, 2, 3, 4, 5, 6, 7, 8]

// 2. 使用 使用数组索引的形式 修改元素
list[1] = 1
println list // [0, 1, 3, 4, 5, 6, 7, 8]

// 3. 修改多个索引处的元素 修改的位置个数 和 对应修改的元素需要一一对应
list[0,1] = [1,2]
println list // [1, 2, 3, 4, 5, 6, 7, 8]

// 4. 修改指定范围的元素 指定范围内的元素个数 元素个数可以与 范围不对应
// 4.1 元素个数大于范围则按照索引位置将对应位置的元素确定 多出的元素按需追加
list[-1..0] = [8,7,6,5,4,3,2,1,0,-1]
println list // [8, 7, 6, 5, 4, 3, 2, 1, 0, -1]
// 4.2 元素个数大于范围则按照索引位置将对应位置的元素确定 空余的位置直接删除
list [-1..0] = [1,2,3]
println list // [1,2,3]
```



##### 列表的排序

```groovy
package basic.dataStructure.list

// list的排序操作

def list = [1, 2, 4, 0, -3, 12, 9, 3, 7, 5]

// 1. 调用和sort方法 从小到大排序
list.sort()
println list // [-3, 0, 1, 2, 3, 4, 5, 7, 9, 12]

// 2. 自定义比较器排序
Comparator c = {
    a, b ->
        return b - a
}
// 从大到小排序
list.sort(c)
println list

// 定义String 列表
list = ["c", "java", "python", "c++", "c#", "groovy"]
// 按照字符长度排序
list.sort {
    it.length()
}
println list // [c, c#, c++, java, python, groovy]
```



##### 元素查找

```groovy
package basic.dataStructure.list

def list = [1, -3, 4, 2, 0, 9, 12, -9, 3]

// 1. 查找符合条件的第一个元素 并返回该元素
println list.find { it % 2 == 0 } // 4

// 2.查找所有符合条件的元素 并收集成一个 Collection 返回
println list.findAll { it % 2 == 0 } // [4, 2, 0, 12]

// 3. 查看list 是否有任意一个元素符合条件
println list.any({
    it > 5
}) // true

// 4. 查看list中的每一个元素是否都满足条件

println list.every {
    it > 5
} // false

// 5. 获取list中的最大最小值
println list.max()
println list.min()

// 6. 返回list处理后的最大最小值
println list.max {
    Math.abs(it)
} // 12

println list.min {
    Math.abs(it)
} // 0

// 7. 统计list中符合条件的元素的个数

println list.count {
    it > 7
} // 2
```





### 映射

* Groovy中的映射 对应的数据类型就是 Java中的Map

#### 映射的定义

* Groovy中 映射(Map)的定义 与Java存在较大的区别 映射在定义时就可以显示赋值
* 在映射中 若key 非数字类型 在不加 '' 的情况下 默认定义为 '' 字符串

```groovy
package basic.dataStructure.map

// 定义映射
def map = [key1: 'value', key2: 'value2']

// 在映射中 需要调用 getClass()方法来获取 映射的类型
println map.getClass() // class java.util.LinkedHashMap
println map // [key1:value, key2:value2]

// 由以上的输出结果可知 映射的默认类型为 LinkedHashMap
// 可以通过 强制类型定义 或者 as 关键字 来转换 映射的类型
// 1. 使用as关键字进行转换
map = map as Hashtable;
println map.getClass() // class java.util.Hashtable

// 2. 定义强制类型
Hashtable hash = [key1: 'value', key2: 'value2']
println hash.getClass() // class java.util.Hashtable

```



#### 映射的操作

##### 新增元素

```groovy
package basic.dataStructure.map

// 定义映射
def map = [key1: 'value1', key2: 'value2']

// 1. 使用put 添加
map.put('key3', 'value3')
println map

// 2. 使用map.keyName 直接添加(不存在则添加 存在则修改)
map.key1 = 'newKey1'
map.key4 = 'key4'
println map
```



##### 删除元素

```groovy
package basic.dataStructure.map

// 定义map
def map = [key1: 'value1', key2: 'value2', key3: 'value4', key4: 'value4']

// 删除映射中的元素
// 1. 按照key删除元素
map.remove('key1')
println map // [key2:value2, key3:value4, key4:value4]

// 2. 按照key value 删除元素
map.remove('key2', 'value2')
println map // [key3:value4, key4:value4]
```



##### 修改元素

```groovy
package basic.dataStructure.map

// 定义map
def map = [key1: 'value1', key2: 'value2', key3: 'value3', key4: 'value4']

// 1. 使用put 修改
map.put('key3', 'newValue3')
println map // [key1:value1, key2:value2, key3:newValue3, key4:value4]

// 2. 使用map.keyName 直接修改(不存在则添加 存在则修改)
map.key1 = 'newKey1'
map.key4 = 'newKey4'
println map // [key1:newKey1, key2:value2, key3:newValue3, key4:newKey4]

```

##### 元素的获取

```groovy
package basic.dataStructure.map

// 定义map
def map = [key1: 'value1', key2: 'value2', key3: 'value3', key4: 'value4']

// 1.使用get()方法 按照 key 获取对应的 value
println map.get('key1') // value1

// 2. 通过数组的形式 获取元素
println map['key1'] // value1

// 3.使用 map.key的形式 获取元素
println map.key1 // value1

```

##### 映射的遍历

```groovy
package basic.dataStructure.map

// 定义Map
def persons = [1: [name: '陈平安', age: 18, gender: 'man'],
               2: [name: '顾璨', age: 15, gender: 'man'],
               3: [name: '刘羡阳', age: 25, gender: 'man'],
               4: [name: '宁姚', age: 18, gender: 'woman']]

// map的遍历
// 1. for循环遍历
for (person in persons) {
    println "name is ${person.value.name}," +
            "age is ${person.value.age}," +
            "gender is ${person.value.gender}"
}
// name is 陈平安,age is 18,gender is man
// name is 顾璨,age is 15,gender is man
// name is 刘羡阳,age is 25,gender is man
// name is 宁姚,age is 18,gender is woman


// 2. each()遍历
persons.each {
    person ->
        println "name is ${person.value.name}," +
                "age is ${person.value.age}," +
                "gender is ${person.value.gender}"

}
// name is 陈平安,age is 18,gender is man
// name is 顾璨,age is 15,gender is man
// name is 刘羡阳,age is 25,gender is man
// name is 宁姚,age is 18,gender is woman


// 3. eachWithIndex()遍历
persons.eachWithIndex { person, int index ->
    println "index is ${index},name is ${person.value.name}," +
            "index is ${index},age is ${person.value.age}," +
            "index is ${index},gender is ${person.value.gender}"

}
// index is 0,name is 陈平安,index is 0,age is 18,index is 0,gender is man
// index is 1,name is 顾璨,index is 1,age is 15,index is 1,gender is man
// index is 2,name is 刘羡阳,index is 2,age is 25,index is 2,gender is man
// index is 3,name is 宁姚,index is 3,age is 18,index is 3,gender is woman


// 3. each()遍历 直接获取 key value
persons.each {
    key, value ->
        println "key is ${key} ,value is ${value}"
}
// key is 1 ,value is [name:陈平安, age:18, gender:man]
// key is 2 ,value is [name:顾璨, age:15, gender:man]
// key is 3 ,value is [name:刘羡阳, age:25, gender:man]
// key is 4 ,value is [name:宁姚, age:18, gender:woman]


// 4. eachWithIndex()遍历 直接获取 key value index
persons.eachWithIndex { key, value, int index ->
    println "index is ${index},key is ${key} ,value is ${value}"
}
// index is 0,key is 1 ,value is [name:陈平安, age:18, gender:man]
// index is 1,key is 2 ,value is [name:顾璨, age:15, gender:man]
// index is 2,key is 3 ,value is [name:刘羡阳, age:25, gender:man]
// index is 3,key is 4 ,value is [name:宁姚, age:18, gender:woman]
```



##### 元素的排序

```groovy
package basic.dataStructure.map;

// 定义Map
def persons = [1: [name: '陈平安', age: 18, gender: 'man', power: 10000],
               2: [name: '顾璨', age: 15, gender: 'man', power: 6000],
               3: [name: '刘羡阳', age: 25, gender: 'man', power: 8000],
               4: [name: '宁姚', age: 18, gender: 'woman', power: 20000]
]

// map的排序
println persons.sort {
    p1, p2 ->
        // 按照战力从小到大排序
        p1.value.power - p2.value.power
} 
// [2:[name:顾璨, age:15, gender:man, power:6000], 
// 3:[name:刘羡阳, age:25, gender:man, power:8000], 
// 1:[name:陈平安, age:18, gender:man, power:10000], 
// 4:[name:宁姚, age:18, gender:woman, power:20000]]
```



##### 元素的查找

```groovy
package basic.dataStructure.map

// 定义Map
def persons = [1: [name: '陈平安', age: 18, gender: 'man', power: 10000],
               2: [name: '顾璨', age: 15, gender: 'man', power: 6000],
               3: [name: '刘羡阳', age: 25, gender: 'man', power: 8000],
               4: [name: '宁姚', age: 18, gender: 'woman', power: 20000]
]

// 1. find() 查找任意一个符合条件的 entry
println persons.find { person ->
    person.value.power > 8888
} // 1={name=陈平安, age=18, gender=man, power=10000}

// 2. findAll() 查找所有满足条件的 entry 封装在一个 map内返回
println persons.findAll { person ->
    person.value.power > 8888
} // [1:[name:陈平安, age:18, gender:man, power:10000], 4:[name:宁姚, age:18, gender:woman, power:20000]]

// 3. 统计persons内 符合条件的元素个数
println persons.count {
    person ->
        person.value.power > 8888
} // 2

// 4 .按条件查找符合条件的元素的个数 并收集指定结果
println persons.findAll {
    person ->
        person.value.power > 8888
}.collect {
    it.value.name
} // [[陈平安, 宁姚]]

// 5. 按条件对元素进行分组
println persons.groupBy {
    person ->
        person.value.power > 10000 ? "战力超群" : "战力尚可"
} // [战力尚可:[1:[name:陈平安, age:18, gender:man, power:10000], 
  //  2:[name:顾璨, age:15,  gender:man, power:6000],
  //  3:[name:刘羡阳, age:25, gender:man, power:8000]],
  // 战力超群:[4:[name:宁姚, age:18, gender:woman, power:20000]]]

```



### 范围

* 范围的本质就是一个List列表 但是更加的轻量 主要用于操作数字

#### 范围的定义与获取

```groovy
package basic.dataStructure.range

// 定义范围 1-10 相当于定义了一个元素为 1-10的list
def range = 1..10

// 元素的获取 与list一致
// 1. 通过索引获取
println range[1] // 3

// 2.判断是否包含某个元素
println range.contains(11) // false

// 3.获取范围的最小值
println range.from // 1
// 4. 获取范围的最大值
println range.to // 10

// 范围的定义 不一定需要从小到大 也支持从大到小
range = 10..1
println range.toListString() // [10, 9, 8, 7, 6, 5, 4, 3, 2, 1]

```



#### 范围的遍历

```groovy
package basic.dataStructure.range

def range = 1..10

// 遍历 range
range.each {
    print it + " "
}
//

// range在 switch中的使用

def getAppraise(Number num) {
    def result
    switch (num) {
         // 0-60之间 不包含60
        case 0..<60:
            result = '不及格'
            break
         // 60-80之间 不包含80
        case 60..<80:
            result = '一般'
            break
        // 80-90之间 不包含90
        case 80..<90:
            result = '良好'
            break
        // 90-100
        case 90..100:
            result = '优秀'
            break
    }
    return result
}

println getAppraise(87) //良好
```





## Groovy面向对象

* Groovy中的面向对象 实质上与Java一致 但是做了一些的拓展 和默认设置 例如 Groovy中所有的类的属性 和 方法 默认为 public 修饰

### Groovy中类、接口的定义和使用

#### 类的定义

##### 类

```groovy
package object

/**
 * Groovy中类的定义
 * 1. 类中的属性 方法 默认都被 public修饰
 */
class Person {

    String name

    Integer age

    String method() {
        return "this method"
    }

    @Override
    String toString(){
        return "name = ${name} , age = ${age}"
    }
}

```

##### 脚本

```groovy
package object

// 定义person类
// 1. 创建对象时 可以使用 属性名: 属性值到的形式 为对象实例化
def person = new Person(name: "陈平安", age: 19)
println person // name = 陈平安 , age = 19

// 2. 创建对象时 通过 对象.属性名 完成实例化 本质上使用的是 属性的 get/set方法
person = new Person()
person.name = '宁姚'
person.age = 18
println person // name = 宁姚 , age = 18
```



#### 接口的定义

##### 接口

```groovy
package object
// 定义接口 
// 接口中的所有抽象方法只能被 public修饰 
interface Action {

    void eat()

    void drink()

    void play()


}
```



#### trait的定义

##### trait

```groovy
package object

/**
 *  trait 介于接口和类之间 可盈以抽象方法 和 实例方法
 *  抽象方法需要添加 abstract 修饰
 */
trait Man {

    abstract eat();

    abstract drink();

    abstract play();

    void study() {
        println "study let me happy!"
    }

}
```

##### 实现类

```groovy
package object;

class Student implements Man {

    @Override
    def eat() {
        return null
    }

    @Override
    def drink() {
        return null
    }

    @Override
    def play() {
        return null
    }

    @Override
    void study() {
        println "good good study , day day up"
    }
}

```



### Groovy中的元编程

* Groovy中的元编程 类似于Java中的动态字节码技术 可以在程序运行时 为 类动态的添加属性和方法 包括静态属性和静态方法 因此在程序编译期间 即使调用了 当前对象对应的类中不存在的方法 编译器也不会报错

#### Groovy中的方法调用流程

![Groovy的方法调用流程](images/Groovy的方法调用流程.png)

#####  测试

###### 测试1

* Person类及父类中不定义 目标方法 且 不重写 methodMissing()方法和invokeMethod()方法

**Human类**

```groovy
package metaClass

class Human {

    void eat() {
        println "human eat food! "
    }
}

```



**Person类 继承 Human**

```groovy
package metaClass;

// 定义Person类
class Person extends Human {
    String name
    int age
}

```



**脚本**

```groovy
package metaClass

// 创建person对象
Person person = new Person(name: "陈平安",age: 18)
person.eat() // human eat food!
// 当前类及父类中都没有 fight() 方法 
person.fight() // groovy.lang.MissingMethodException: No signature of method: metaClass.Person.fight() is applicable for argument types: () values: []
```



###### 测试2

* Person类及父类中不定义目标方法 仅重写 invokeMethod()方法

**Human类**

```groovy
package metaClass

class Human {

    void eat() {
        println "human eat food! "
    }
}

```



**Person类 继承 Human**

```groovy
package metaClass;

// 定义Person类
class Person extends Human {
    String name
    int age

    /**
     * 当目标方法不存在 且位重写 methodMissing()方法的情况下 该方法执行
     * @param name 当前调用的目标方法方法名
     * @param args 当前调用的目标方法参数
     */
    @Override
    def invokeMethod(String name, Object args) {
        println "method name for ${name} , parameter for ${args} is invoked !"
    }
}

```



**脚本**

```groovy
package metaClass

// 创建person对象
Person person = new Person(name: "陈平安",age: 18)
person.eat() // human eat food!
// 当前类及父类中都没有 fight() 方法 
person.fight() // method name for fight , parameter for [] is invoked !
```



###### 测试3

* Person类及父类中不定义目标方法 重写 invokeMethod()方法和MethodMissing()方法

**Human类**

```groovy
package metaClass

class Human {

    void eat() {
        println "human eat food! "
    }
}

```



**Person类 继承 Human**

```groovy
package metaClass;

// 定义Person类
class Person extends Human {
    String name
    int age


    /**
     * 当目标方法不存在 调用该方法
     * @param name 当前调用的目标方法方法名
     * @param args 当前调用的目标方法参数
     */
    def methodMissing(String name, Object args){
        println "method name for ${name} , parameter for ${args} is missing !"
    }


    /**
     * 当目标方法不存在 且未重写 methodMissing()方法的情况下 该方法执行
     * @param name 当前调用的目标方法方法名
     * @param args 当前调用的目标方法参数
     */
    @Override
    def invokeMethod(String name, Object args) {
        println "method name for ${name} , parameter for ${args} is invoked !"
    }
}

```



**脚本**

```groovy
package metaClass

// 创建person对象
Person person = new Person(name: "陈平安",age: 18)
person.eat() // human eat food!
// 当前类及父类中都没有 fight() 方法 
person.fight() // method name for fight , parameter for [] is missing !
```



###### 测试4

* Human中定义 methodMissing()方法

**Human类**

```groovy
package metaClass

class Human {

    void eat() {
        println "human eat food! "
    }
    
      /**
     * 当目标方法不存在 调用该方法
     * @param name 当前调用的目标方法方法名
     * @param args 当前调用的目标方法参数
     */
    def methodMissing(String name, Object args){
        println "method name for ${name} , parameter for ${args} is missing !"
    }


    /**
     * 当目标方法不存在 且未重写 methodMissing()方法的情况下 该方法执行
     * @param name 当前调用的目标方法方法名
     * @param args 当前调用的目标方法参数
     */
    @Override
    def invokeMethod(String name, Object args) {
        println "method name for ${name} , parameter for ${args} is invoked !"
    }
}

```



**Person类 继承 Human**

```groovy
package metaClass;

// 定义Person类
class Person extends Human {
    String name
    int age
}

```



**脚本**

```groovy
package metaClass

// 创建person对象
Person person = new Person(name: "陈平安",age: 18)
person.eat() // human eat food!
// 当前类及父类中都没有 fight() 方法 
person.fight() // method name for fight , parameter for [] is missing !
```



#### metaClass的使用

* 在Groovy中定义的类 都会默认继承 GroovyObject 在 GroovyObject 中提供了 metaClass的设置和获取的方法 
* 获取到 metaClass 后就可以对类进行动态操作 在程序运行时动态的添加 属性 或者方法



# Groovy实战

## Groovy操作Json



## Groovy解析XML



## Groovy 生成XML



## Groovy文件处理



